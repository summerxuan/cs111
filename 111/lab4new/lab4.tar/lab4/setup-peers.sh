./osppeer -dbase -t164.67.100.231:12997&
./osppeer -dbase -t164.67.100.231:12998 -s &
./osppeerbad -dbase -t164.67.100.231:12999 -b &
./osppeerbad -dbase -t164.67.100.231:12999 -b &
./osppeer -dbase -t164.67.100.231:13000 &
