/usr/local/cs/bin/osptracker -p12997&
/usr/local/cs/bin/osptracker -p12998&
/usr/local/cs/bin/osptracker -p12999&
/usr/local/cs/bin/osptracker -p13000 -f&
